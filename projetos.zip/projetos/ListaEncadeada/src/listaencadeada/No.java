/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEncadeada;



/**
 *
 * @author tatiane
 */
public class No {
    
    private Aluno conteudo;
    private No prox;

    public Aluno getConteudo() {
        return conteudo;
    }

    public No getProx() {
        return prox;
    }

    public void setConteudo(Aluno conteudo) {
        this.conteudo = conteudo;
    }

    public void setProx(No prox) {
        this.prox = prox;
    }
    
    
    
}
