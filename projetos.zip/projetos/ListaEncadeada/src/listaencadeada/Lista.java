 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEncadeada;



/**
 *
 * @author tatiane
 */
public class Lista {

    private No inicio;
    private int tam;

    public void addInicio(Aluno a) {

        No n = new No();
        n.setConteudo(a);
        n.setProx(inicio);
        inicio = n;
        tam++;

    }

    public void addFim(Aluno a) {

        if (tam == 0) {
            this.addInicio(a);
        } else {
            No n = new No();
            n.setConteudo(a);
            No aux = inicio;
            while (aux.getProx() != null) {
                aux = aux.getProx();
            }
            aux.setProx(n);
            tam++;
        }
    }

    public void add(Aluno a, int posicao) {

        if (posicao == 0) {
            this.addInicio(a);
        } else if (posicao == tam) {
            this.addFim(a);
        } else {
            No n = new No();
            n.setConteudo(a);

            if (posicao > 0 && posicao < tam) {

                No aux = inicio;
                int cont = 0;
                while (cont < posicao - 1) {
                    cont++;
                    aux = aux.getProx();
                }

                n.setProx(aux.getProx());
                aux.setProx(n);
                tam++;

            }
        }
    }
    
    public void remove(int posicao) {
        if( posicao >= 0 && posicao <=tam){
            
        }

    }

   

    public void percorre() {
        
        No aux = inicio;
        System.out.println("nome: " + aux.getConteudo().getNome());
        while(aux.getProx() != null){
            aux = aux.getProx();
            System.out.println("nome: " + aux.getConteudo().getNome());
        }
    }

}
