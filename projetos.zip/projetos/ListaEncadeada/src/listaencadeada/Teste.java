/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEncadeada;




/**
 *
 * @author tatiane
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Aluno a1 = new Aluno();
        a1.setNome("Pedro");
        
        Aluno a2 = new Aluno();
        a2.setNome("Joao");
        
        Aluno a3 = new Aluno();
        a3.setNome("Maria");
        
        
        Lista lista = new Lista();
        lista.add(a1, 0);
        lista.add(a2, 1);
        lista.add(a3, 1);
        
        lista.percorre();
        
                }
    
}
