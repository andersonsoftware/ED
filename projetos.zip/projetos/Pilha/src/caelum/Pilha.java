package caelum;

import java.util.LinkedList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Painel.quixere
 */
public class Pilha<T> {
    
    private final List<T> objetos = new LinkedList<T>();
      
    public void insere (T t){
        // adiciona usando metodo Object
        this.objetos.add(t);        
    }
    
    public Object remove (){
        return this.objetos.remove(this.objetos.size() -1);
        // remove o tamanho e logo após o anterior        
    }
    
        public boolean Vazia(){               
        return this.objetos.isEmpty();// verifica se a lista está vazia
    }

    boolean vazia() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
      
    
}
