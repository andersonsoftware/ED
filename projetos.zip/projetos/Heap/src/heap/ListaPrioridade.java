/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heap;

/**
 *
 * @author Painel.quixere
 */
public class ListaPrioridade {
    
    private final int [] lista = new int [100];
    private int tam;
    
    public void subir (int i){
        int j = i/2;
        if(j >= 1){
            if(lista[i] >= lista [j]){
                int aux = lista[i];
                lista[i] = lista[j];
                lista[j] = aux; 
                subir(j);
            }
        }
        
    }
    
    public void descer (int i){
        
    }
    
    public void inserir (int x){
        
    }
    
    public int remover (){
        if(tam == 0){
            throw new IllegalArgumentException("está vazio");
        }
        return 0;
    }
    
}

