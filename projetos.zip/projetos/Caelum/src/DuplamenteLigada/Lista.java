/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DuplamenteLigada;



/**
 * Adiciona um dado elemento no fim da Lista. 
 * Adiciona um dado elemento em um dada posição.
 * Pega o elemento de uma dada posição. 
 * Remove o elemento de uma dada posição.
    Verifica se um dado elemento está contido na Lista. 
 * Informa a quantidade de elementos da Lista.
 */
public class Lista {

    //private int posicao;
    private int totalDeAlunos = 0;

    // Declarando e Inicializando um array de Aluno com capacidade 100.
    private final Aluno[] lista = new Aluno[100];

    public int getTotalDeAlunos() {
        // * Informa a quantidade de elementos da Lista.
        return totalDeAlunos;
    }

    public void adiciona(Aluno aluno) {
        //adicionar aluno no final da lista(constante)
        if (totalDeAlunos < lista.length) {
            lista[totalDeAlunos] = aluno;
            totalDeAlunos++;
        }
    }

    public void adiciona(int posicao, Aluno aluno) {
        //Adicionar um aluno em uma determinada posição do array
        if (!this.posicaoValida(posicao)) {
            throw new IllegalArgumentException("Posição inválida");
        }

        for (int i = this.totalDeAlunos - 1; i >= posicao; i -= 1) {
            this.lista[i + 1] = this.lista[i];
        }

        this.lista[posicao] = aluno;
        this.totalDeAlunos++;
    }

    private boolean posicaoValida(int posicao) {
        return posicao >= 0 && posicao <= this.totalDeAlunos;
    }

    public boolean contem(Aluno aluno) {
        //Verificar se um aluno está presente no vetor
        for (int i = 0; i < this.totalDeAlunos; i++) {
            if (aluno.equals(this.lista[i])) {
                return true;
            }
        }
        return false;
    }

    public Aluno Buscar(int posicao) {
        //* Pega o elemento de uma dada posição usando ifs
        /*
        if (posicao > 0 && posicao < totalDeAlunos) {
        }
         */
        //* Pega o elemento de uma dada posição sem if
        if (!this.posicaoOcupada(posicao)) {
            throw new IllegalArgumentException("Posição inválida");
        }
        return this.lista[posicao];
    }

    private boolean posicaoOcupada(int posicao) {
        return posicao >= 0 && posicao < this.totalDeAlunos;
    }

    /*
    public Aluno BuscarId(int id) {
        //Buscar por aluno por ID
        for (int i = 0; i < totalDeAlunos; i++) {
            if (lista[i]  getId() == id
            
                ){
                return lista[i];
            }
        }
    }
     */
    public void remove(int posicao) {
        // * Remove o elemento de uma dada posição.
        if (posicao >= 0 && posicao < totalDeAlunos) {
            Aluno aux = lista[posicao];
            for (int i = posicao; i < totalDeAlunos; i++) {
                lista[i] = lista[i + 1];

            }

        }

    }

    @Override
    public String toString() {
        if (this.totalDeAlunos == 0) {
            return "[]";
        }

        StringBuilder builder = new StringBuilder();
        builder.append("[");

        for (int i = 0; i < this.totalDeAlunos - 1; i++) {
            builder.append(this.lista[i]);
            builder.append(", ");
        }

        builder.append(this.lista[this.totalDeAlunos - 1]);
        builder.append("]");

        return builder.toString();
    }
    
}

