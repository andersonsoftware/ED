/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banco;

/**
 *
 * @author Painel.quixere
 */
public class ContaBanco {
    
    public int numConta;
    protected String tipo;
    private String Dono;
    private double saldo;
    private boolean status;
    
     public ContaBanco(){
    saldo = 0;
    status = false;
    }
    

    public int getNumConta() {
        return numConta;
    }

    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDono() {
        return Dono;
    }

    public void setDono(String Dono) {
        this.Dono = Dono;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    
   
    public void abrirConta(String tipo){
        
    }
    public void fecharConta(){
        
    }
    public void depositar(double valor){
        
    }
    public void sacar(double valor){
        
    }
    public void pagarMensal(double valor){
        
    }
}
