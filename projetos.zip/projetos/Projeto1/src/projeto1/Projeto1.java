/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto1;

/**
 *
 * @author Painel.quixere
 */
public class Projeto1 {

    /**
     * @param args the command line arguments
     */
  
    public static void main(String[] args) {
        Aluno a1 = new Aluno();
        Aluno a2 = new Aluno();
        Aluno a3 = new Aluno();

        a1.setNome("Rafael");
        a2.setNome("Paulo");
        a3.setNome("Anderson");
        
               
        Vetor list =   new Vetor();
        list.addEnd(a1);
        list.addEnd(a2);
        list.addEnd(a3);
        
        System.out.println(list.toString());
        System.out.println(list.size());
        
        list.removeLast();
        System.out.println(list.toString());
        System.out.println(list.size());
       
        list.removeLast();
        System.out.println(list.toString());
        System.out.println(list.size());
        
        list.removeLast();
        //System.out.println(list.toString());
        System.out.println(list.size());
        
        
        
      /*
        list.remove(0);
        
        System.out.println(list.toString());
        
        System.out.println(list.size());
  
        
        list.removeFirst();
        
        System.out.println(list.toString());
        
        System.out.println(list.size());
        
        list.removeLast();
       
           
        
        System.out.println(list.size());
        //list.remove(0);
*/    
}

}
            
        
        

