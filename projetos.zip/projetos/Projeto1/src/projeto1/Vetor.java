/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto1;

/**
1 - Considere um array de inteiros positivos de tamanho 100. Faça as seguintes questões:
1.1 - Sabendo que neste array é aceito a inserção de elementos iguais. Crie os seguintes métodos:
a) Adicionar um elemento no início da lista;
b) Adicionar um elemento no final da lista;
c) Adicionar um elemento na n-ésima posição da lista;
d) Remover o primeiro elemento da lista;
e) Remover o último elemento da lista;
f) Remover o n-ésimo elemento da lista;
g) Imprimir os elementos da lista de forma iterativa;
h) Retornar o número de elementos da lista;
1.2 - Qual a complexidade de cada método?
1.3 - Qual o maior problema quanto a fixação de tamanho do array? Como você resolveria esse
problema?

 */
public class Vetor {

    private Object[] objects;
    int totalOfObjects;
    
   
    public Vetor() {
        this.objects = new Object[100];
        this.totalOfObjects = 0;
    }

    //a) Adicionar um elemento no início da lista;
    public void add(Object object) {
        this.checkSpace();
        
        this.objects[this.totalOfObjects] = object;
        this.totalOfObjects++;
    }

    //b) Adicionar um elemento no final da lista;
    public void addEnd(Object object) {
        this.checkSpace();
        this.objects[this.totalOfObjects] = object;
        this.totalOfObjects++;
    }
    
    //c) Adicionar um elemento na n-ésima posição da lista;
    public void addAny(int posicao, Object object) {
        this.checkSpace();
        if (!validPosition(posicao)) {
            throw new IllegalArgumentException("Posição inválida");
        }
        for (int i = this.totalOfObjects - 1; i >= posicao; i -= 1) {
            this.objects[i + 1] = this.objects[i];
        }
        this.objects[posicao] = object;
        this.totalOfObjects++;
    }
    
    //d) Remover o primeiro elemento da lista;
    
    public void removeFirst(){
        if (this.totalOfObjects == 0){
            throw new IllegalArgumentException("lista está vazia");
        }
        for (int i = this.totalOfObjects; i <= 0; i--){
            this.objects[i +1] = this.objects [i];
            }
        this.totalOfObjects--;
    }
    
    //e) Remover o último elemento da lista;
    public void removeLast(){
        if (this.totalOfObjects == 0){
            throw new IllegalArgumentException("lista está vazia");
        }
        for (int i = 0; i <= this.totalOfObjects -1; i++ ){
            this.objects [this.totalOfObjects] = this.objects[i + 1];
        }
        this.totalOfObjects--;
    }
    

    //f) Remover o n-ésimo elemento da lista;
    public void remove(int position) {
        if (!this.occupiedPosition(position)) {
            throw new IllegalArgumentException("Posição inválida");
        }
        for (int i = position; i < this.totalOfObjects - 1; i++) {
            this.objects[i] = this.objects[i + 1];
        }
        this.totalOfObjects--;
    }

  
    //g) Imprimir os elementos da lista de forma iterativa;
    public String toString() {
        if (this.totalOfObjects == 0) {
            return "[]";
        }

        StringBuilder builder = new StringBuilder();
        builder.append("[");

        for (int i = 0; i < this.totalOfObjects - 1; i++) {
            builder.append(this.objects[i]);
            builder.append(", ");
        }

        builder.append(this.objects[this.totalOfObjects - 1]);
        builder.append("]");

        return builder.toString();
    }

    //verificar se uma dada posição está ocupada
    private boolean occupiedPosition(int position) {
        return position >= 0 && position < this.totalOfObjects;
    }

    //verificar uma posição válida
    private boolean validPosition(int position) {
        return position >= 0 && position <= this.totalOfObjects;
    }

    //1.3 - Qual o maior problema quanto a fixação de tamanho do array?
    //      Como você resolveria esse problema?
    //verificar se tem espaço no array
    private void checkSpace() {
        if (this.totalOfObjects == this.objects.length) {
            Object[] newArray = new Object[this.objects.length * 2];
            for (int i = 0; i < this.objects.length; i++) {
                newArray[i] = this.objects[i];
            }
            this.objects = newArray;
        }
    }
    
      //h) Retornar o número de elementos da lista;
    public int size() {
        return this.totalOfObjects;
    }
}    
