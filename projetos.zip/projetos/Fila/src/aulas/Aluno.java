/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulas;

/**
Interface da Lista:


 */
public class Aluno {
    
    private String nome;
    private  String dataNasc;
    private int cpf;
    private int id;
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public int getId() {
        return id;
    }

    public void setId(int matricula) {
        this.id = matricula;
    }
      
    @Override
    public boolean equals (Object o){
        Aluno outro = (Aluno)o;
        return this.nome.equals(outro.nome);
    }
    
}
