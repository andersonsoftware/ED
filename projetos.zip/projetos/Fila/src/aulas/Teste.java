/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulas;

/**
 *
 * @author Painel.quixere
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Aluno a1 = new Aluno();
        a1.setNome("anderson");
        
        Aluno a2 = new Aluno();
        a2.setNome("Gilmario");
        
        Aluno a3 = new Aluno();
        a3.setNome("Gilmario");
        
        Pilha pilha = new Pilha();
        
        
        pilha.adicionaFim(a1);
        pilha.adicionaFim(a2);
        pilha.adicionaFim(a3);
                       
              
        pilha.imprime();
        System.out.println(pilha.tamanho());
        
        pilha.removeDoComeco();
        pilha.removeDoComeco();
        pilha.removeDoComeco();
        
        
        pilha.imprime();
        System.out.println(pilha.tamanho());
        
         
    }
    
}
