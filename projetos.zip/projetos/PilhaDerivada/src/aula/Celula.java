package aula;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Painel.quixere
 */
public class Celula {

  private Celula proxima;
  private Celula anterior;
  private Object elemento;
  
  
  public void setAnterior(Celula posicao){
      this.anterior = posicao;
  }
  public Celula getAnterior(){
      return this.anterior;
  }
  public Celula(Celula proxima, Object elemento) {
    this.proxima = proxima;
    this.elemento = elemento;
  }

  public Celula(Object elemento) {
    this.elemento = elemento;
  }

  public void setProxima(Celula proxima) {
    this.proxima = proxima;
  }

  public Celula getProxima() {
    return proxima;
  }
  
  public Object getElemento() {
    return elemento;
  }
  
  
}
