 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEncadeada;

import ListaEncadeada.No;

/**
 *
 * @author tatiane
 */
public class Lista {

    private No inicio;
    private No fim;
    private int tam = 0;
    
    //a) Adicionar um elemento no início da lista;
    public void addInicio(int a) {
        if(this.tam == 0){
            No n = new No();
            n.setConteudo(a);
            n.setProximo(inicio);
            this.inicio = n;
            this.fim = n;
            tam++;
        }else{
        No n = new No();
        n.setConteudo(a);
        n.setProximo(inicio);
        inicio = n;
        tam++;
        }
        
        
    }

    public int getTam() {
        return tam;
    }
    //b) Adicionar um elemento no final da lista;
    public void addFim(int a) {
        
        if (this.tam == 0) {
            this.addInicio(a);
        } else {
            No n = new No();
            n.setConteudo(a);
            this.fim.setProximo(n);
            this.fim = n;
            this.tam++;
        }
    }
    //c) Adicionar um elemento na n-ésima posição da lista;
    public void add(int posicao, int a) {
        if(!posicaoOcupada(posicao -1)){
            throw new IllegalArgumentException("posição inválida");
        }else if (posicao == 1) {
            this.addInicio(a);
        } else if (posicao == tam) {
            this.addFim(a);
        } else {
            No n = new No();
            n.setConteudo(a);
            if (posicao > 0 && posicao < tam) {
                No aux = inicio;
                int cont = 0;
               
                while (cont < posicao - 1) {
                    cont++;
                    aux = aux.getProximo();
                }

                n.setProximo(aux.getProximo());
                aux.setProximo(n);
                tam++;

            }
        }
    }
    
    // d) Remover o primeiro elemento da lista;
    public void removeComeco(){
        
    }
    
    public void remove(int posicao) {
        if( posicao >= 0 && posicao <=tam){
            
        }

    }

    public void imprimir(){
        System.out.println("**********************");
        
        No aux = inicio;
        System.out.print("Elementos:  "+ aux.getConteudo()+ "\t  ");
        while(aux.getProximo() != null){
            aux = aux.getProximo();
            System.out.print(aux.getConteudo()+ "\t");
        }
        System.out.println("");
        System.out.println("**********************");
    }
    
    
    public int quantidade(){
        System.out.print("Quantidade: "+ this.tam +" \n");
        return tam;
    } 

        
    private boolean posicaoOcupada(int posicao){
        return posicao >= 0 && posicao < this.tam;
    }
    public void percorre() {
        
        No aux = inicio;
        System.out.println("nome: " + aux.getConteudo());
        while(aux.getProximo()!= null){
            aux = aux.getProximo();
            System.out.println("nome: " + aux.getConteudo());
        }
    }

}
