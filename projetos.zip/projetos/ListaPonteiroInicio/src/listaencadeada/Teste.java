/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEncadeada;




/**
 *
 * @author tatiane
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Lista lista = new Lista();
        
        lista.addInicio(6);
        lista.addInicio(5);
        lista.addInicio(4);
        lista.addInicio(3);
        lista.addInicio(2);
        lista.addInicio(1);
        
        lista.imprimir();
        lista.quantidade();
        
        lista.addFim(7);
        lista.imprimir();
        lista.quantidade();
        
        lista.add(7, 3);
        lista.imprimir();
        lista.quantidade();
        
        
        
      
        
                }
    
}
